# Adonis Anthony David Hernández Pérez - 1086223
import tkinter as tk
from tkinter import filedialog, messagebox
import re
import os

BLANCO = "_"

#  Máquina de Turing básica
class MaquinaTuring:
    def __init__(self, nombre, estados, alfabeto, blanco, q0, aceptacion, T):
        self.nombre = nombre
        self.estados = set(estados)
        self.alfabeto = set(alfabeto) | {blanco}
        self.blanco = blanco
        self.q0 = q0
        self.aceptacion = set(aceptacion)
        self.T = dict(T)
        self.qR = 'qR'
        self.reiniciar("")

    def reiniciar(self, cadena):
        self.cinta = list(cadena) if cadena is not None else []
        if not self.cinta:
            self.cinta = [self.blanco]
        if self.cinta[-1] != self.blanco:
            self.cinta.append(self.blanco)
        self.i = 0
        self.q = self.q0
        self.pasos = 0

    def _expandir(self):
        if self.i < 0:
            self.cinta.insert(0, self.blanco)
            self.i = 0
        if self.i >= len(self.cinta):
            self.cinta.append(self.blanco)

    def paso(self):
        if self.q in self.aceptacion or self.q == self.qR:
            return False
        self._expandir()
        s = self.cinta[self.i]
        clave = (self.q, s)
        if clave not in self.T:
            self.q = self.qR
            return False
        nq, escribir, mover = self.T[clave]
        self.cinta[self.i] = escribir
        if mover == 'R':
            self.i += 1
        elif mover == 'L':
            self.i -= 1
        self.q = nq
        self.pasos += 1
        return True

    def aceptar(self):
        return self.q in self.aceptacion


#  Máquinas de Turing para las 5 expresiones

def mt_ab_star():
    # (ab)*
    estados = {"q0","q1","qA","qR"}
    alf = {'a','b'}
    T = {}
    T[("q0", 'a')] = ("q1", 'a', 'R')
    T[("q1", 'b')] = ("q0", 'b', 'R')
    T[("q0", BLANCO)] = ("qA", BLANCO, 'S')
    T[("q1", BLANCO)] = ("qR", BLANCO, 'S')
    for q in ["q0","q1"]:
        for a in alf:
            if (q,a) not in T:
                T[(q,a)] = ("qR", a, 'S')
    return MaquinaTuring("(ab)*", estados, alf, BLANCO, "q0", {"qA"}, T)


def mt_termina_abb():
    # (a|b)*abb
    estados = {"q0","q1","q2","q3","qA","qR"}
    alf = {'a','b'}
    T = {}
    T[("q0", 'a')] = ("q1", 'a', 'R')
    T[("q0", 'b')] = ("q0", 'b', 'R')
    T[("q1", 'a')] = ("q1", 'a', 'R')
    T[("q1", 'b')] = ("q2", 'b', 'R')
    T[("q2", 'a')] = ("q1", 'a', 'R')
    T[("q2", 'b')] = ("q3", 'b', 'R')
    T[("q3", 'a')] = ("q1", 'a', 'R')
    T[("q3", 'b')] = ("q0", 'b', 'R')
    T[("q3", BLANCO)] = ("qA", BLANCO, 'S')
    for q in ["q0","q1","q2"]:
        T[(q, BLANCO)] = ("qR", BLANCO, 'S')
    return MaquinaTuring("(a|b)*abb", estados, alf, BLANCO, "q0", {"qA"}, T)


def mt_0_star_1_star():
    # 0*1*
    estados = {"q0","q1","qA","qR"}
    alf = {'0','1'}
    T = {}
    T[("q0", '0')] = ("q0", '0', 'R')
    T[("q0", '1')] = ("q1", '1', 'R')
    T[("q1", '1')] = ("q1", '1', 'R')
    T[("q1", '0')] = ("qR", '0', 'S')
    T[("q0", BLANCO)] = ("qA", BLANCO, 'S')
    T[("q1", BLANCO)] = ("qA", BLANCO, 'S')
    return MaquinaTuring("0*1*", estados, alf, BLANCO, "q0", {"qA"}, T)


def mt_1_01_star_0():
    # 1(01)*0
    estados = {"q0","q1","q2","q3","qA","qR"}
    alf = {'0','1'}
    T = {}
    T[("q0", '1')] = ("q1", '1', 'R')
    # después de 1, si vemos 0 puede ser el final o parte de (01)
    T[("q1", '0')] = ("q3", '0', 'R')
    # si después de ese 0 hay 1, regresamos a q1 (consumimos un bloque 01)
    T[("q3", '1')] = ("q1", '1', 'R')
    # si después de ese 0 hay blanco, fin correcto
    T[("q3", BLANCO)] = ("qA", BLANCO, 'S')
    # rechazos
    T[("q0", '0')] = ("qR", '0', 'S')  # debe iniciar con 1
    T[("q1", '1')] = ("qR", '1', 'S')  # tras 1 no puede venir 1
    T[("q1", BLANCO)] = ("qR", BLANCO, 'S')
    T[("q3", '0')] = ("qR", '0', 'S')  # tras el 0 no puede venir 0
    return MaquinaTuring("1(01)*0", estados, alf, BLANCO, "q0", {"qA"}, T)


def mt_contiene_a():
    # (a|b)*a(a|b)*  -> contiene al menos una 'a'
    estados = {"q0","q1","qA","qR"}
    alf = {'a','b'}
    T = {}
    T[("q0", 'a')] = ("q1", 'a', 'R')
    T[("q0", 'b')] = ("q0", 'b', 'R')
    T[("q0", BLANCO)] = ("qR", BLANCO, 'S')  # si nunca vimos 'a'
    for a in alf:
        T[("q1", a)] = ("q1", a, 'R')
    T[("q1", BLANCO)] = ("qA", BLANCO, 'S')
    return MaquinaTuring("(a|b)*a(a|b)*", estados, alf, BLANCO, "q0", {"qA"}, T)

# Mapeo expresión -> fábrica de MT
FABRICAS = {
    "(a|b)*abb": mt_termina_abb,
    "0*1*": mt_0_star_1_star,
    "(ab)*": mt_ab_star,
    "1(01)*0": mt_1_01_star_0,
    "(a|b)*a(a|b)*": mt_contiene_a,
}

EXPRESIONES_FIJAS = list(FABRICAS.keys())


# Interfaz gráfica

class App:
    def __init__(self, root):
        self.root = root
        root.title("Simulador de Máquina de Turing — 5 expresiones")
        root.geometry("680x520")
        self.cadenas = []
        self.idx_cadena = 0
        self.mt = None
        self.pausa_ms = 120
        self.max_pasos = 2000

        # Barra superior
        top = tk.Frame(root); top.pack(fill='x', padx=10, pady=6)
        tk.Button(top, text="Cargar cadenas.txt", command=self.cargar_cadenas).pack(side='left')
        tk.Button(top, text="Simular TODAS (5×N)", command=self.procesar_todas).pack(side='left', padx=8)
        self.lbl_arch = tk.Label(top, text="Cadenas: 0"); self.lbl_arch.pack(side='right')

        # Lista de expresiones
        mid = tk.Frame(root); mid.pack(fill='x', padx=10, pady=(0,6))
        tk.Label(mid, text="Expresión (elige una):").pack(anchor='w')
        self.lst = tk.Listbox(mid, width=40, height=6)
        self.lst.pack(anchor='w')
        for e in EXPRESIONES_FIJAS:
            self.lst.insert('end', e)
        self.lst.bind('<<ListboxSelect>>', self._al_elegir_expresion)
        self.lst.selection_set(0)

        # Controles
        ctrl = tk.Frame(root); ctrl.pack(fill='x', padx=10, pady=(0,6))
        tk.Button(ctrl, text="Anterior", command=self.anterior_cadena).pack(side='left')
        tk.Button(ctrl, text="Siguiente", command=self.siguiente_cadena).pack(side='left', padx=6)
        tk.Button(ctrl, text="Reiniciar cadena", command=self.reiniciar_cadena).pack(side='left', padx=6)
        tk.Button(ctrl, text="Paso", command=self.paso).pack(side='left', padx=6)
        tk.Button(ctrl, text="Auto (cadena actual)", command=self.auto_actual).pack(side='left', padx=6)

        # Estado
        info = tk.Frame(root); info.pack(fill='x', padx=10)
        self.lbl_cad = tk.Label(info, text="Cadena actual: —"); self.lbl_cad.pack(side='left')
        self.lbl_info = tk.Label(info, text="Estado: - | Paso: - | Cabezal: -"); self.lbl_info.pack(side='right')

        # Cinta
        cinta = tk.Frame(root); 
        cinta.pack(fill='both', expand=True, padx=10, pady=6)
        self.lbl_cinta = tk.Label(cinta, text="Cinta:", font=("Courier New", 14)); 
        self.lbl_cinta.pack(anchor='w')
        self.lbl_flecha = tk.Label(cinta, text="^", font=("Courier New", 14)); 
        self.lbl_flecha.pack(anchor='w')

        # Resultados
        res = tk.Frame(root); res.pack(fill='both', expand=True, padx=10, pady=(0,10))
        tk.Label(res, text="Resultados:").pack(anchor='w')
        self.txt = tk.Text(res, height=10); self.txt.pack(fill='both', expand=True)
        self.txt.configure(state='disabled')

        self._fabricar_mt(EXPRESIONES_FIJAS[0])
        self._actualizar(True)

    # Archivos
    def cargar_cadenas(self):
        ruta = filedialog.askopenfilename(title='Selecciona cadenas.txt', filetypes=[('Texto','*.txt')])
        if not ruta:
            return
        try:
            with open(ruta, 'r', encoding='utf-8') as f:
                # quitar solo saltos de línea; conservar vacías
                self.cadenas = [l.rstrip('\r\n') for l in f.readlines()]
            self.idx_cadena = 0
            self.lbl_arch.config(text=f"Cadenas: {len(self.cadenas)}")
            self.reiniciar_cadena()
            messagebox.showinfo('Listo', f'Se cargaron {len(self.cadenas)} cadenas.')
        except Exception as e:
            messagebox.showerror('Error', f'No se pudo leer cadenas.txt\n{e}')

    # MT por expresión
    def _al_elegir_expresion(self, *_):
        sel = self.lst.curselection()
        if not sel:
            return
        patron = EXPRESIONES_FIJAS[sel[0]]
        self._fabricar_mt(patron)
        self.reiniciar_cadena()

    def _fabricar_mt(self, patron):
        fab = FABRICAS.get(patron)
        self.mt = fab() if fab else None
        self._set_resultados(f"Expresión seleccionada: {patron}\n")

    # navegación / ejecución 
    def anterior_cadena(self):
        if self.idx_cadena > 0:
            self.idx_cadena -= 1
            self.reiniciar_cadena()

    def siguiente_cadena(self):
        if self.idx_cadena < len(self.cadenas)-1:
            self.idx_cadena += 1
            self.reiniciar_cadena()

    def reiniciar_cadena(self):
        cad = self.cadenas[self.idx_cadena] if self.cadenas else ""
        if self.mt:
            self.mt.reiniciar(cad)
        self._actualizar(True)

    def paso(self):
        if self.mt is None:
            return
        if self.mt.paso():
            self._actualizar(False)
        else:
            self._actualizar(False)
            self._mostrar_resultado()

    def auto_actual(self):
        if self.mt is None:
            self._mostrar_resultado(); return
        def _loop():
            if self.mt.paso() and self.mt.pasos < self.max_pasos:
                self._actualizar(False)
                self.root.after(self.pausa_ms, _loop)
            else:
                self._actualizar(False)
                self._mostrar_resultado()
        _loop()

    # pintar 
    def _segmento(self):
        if self.mt is None:
            return "(sin MT)", ""
        # Cinta completa, sin el símbolo BLANCO ("_")
        cinta_txt = "".join(ch if ch != BLANCO else " " for ch in self.mt.cinta)
        # Offset = largo de "Cinta: " + posición real del cabezal
        flecha = " " * (len("Cinta: ") + self.mt.i) + "^"
        return cinta_txt, flecha

    def _actualizar(self, limpiar):
        total = len(self.cadenas)
        pos = self.idx_cadena + 1 if total else 0
        cad = self.cadenas[self.idx_cadena] if self.cadenas else ""
        ver = cad if len(cad) <= 60 else cad[:60] + '…'
        self.lbl_cad.config(text=f"Cadena ({pos}/{total}): {ver}")
        cinta, flecha = self._segmento()
        self.lbl_cinta.config(text="Cinta: " + cinta)
        self.lbl_flecha.config(text=flecha)
        est = '-' if self.mt is None else self.mt.q
        pas = '-' if self.mt is None else self.mt.pasos
        cab = '-' if self.mt is None else self.mt.i
        self.lbl_info.config(text=f"Estado: {est} | Paso: {pas} | Cabezal: {cab}")
        if limpiar:
            self._set_resultados("")

    def _mostrar_resultado(self):
        cad = self.cadenas[self.idx_cadena] if self.cadenas else ""
        # MT
        if self.mt.aceptar():
            linea1 = "Resultado MT: ACEPTADA ✅\n"
        elif self.mt.q == self.mt.qR:
            linea1 = "Resultado MT: RECHAZADA ❌\n"
        else:
            linea1 = "Resultado MT: DETENIDA\n"
        # Regex de la misma expresión
        patron = EXPRESIONES_FIJAS[self.lst.curselection()[0]] if self.lst.curselection() else EXPRESIONES_FIJAS[0]
        try:
            ok = re.fullmatch(patron, cad) is not None
            linea2 = f"Regex '{patron}': " + ("SI" if ok else "NO") + "\n"
        except re.error as e:
            linea2 = f"Regex '{patron}': ERROR {e}\n"
        self._set_resultados(linea1 + linea2)

    def procesar_todas(self):
        if not self.cadenas:
            messagebox.showwarning('Falta archivo','Carga cadenas.txt.'); return
        res = []
        for patron in EXPRESIONES_FIJAS:
            fab = FABRICAS.get(patron)
            for cad in self.cadenas:
                r_mt = "(sin MT)"
                if fab is not None:
                    mt = fab(); mt.reiniciar(cad)
                    pasos = 0
                    while pasos < self.max_pasos and mt.paso():
                        pasos += 1
                    r_mt = "ACEPTADA" if mt.aceptar() else ("RECHAZADA" if mt.q==mt.qR else "DETENIDA")
                try:
                    ok = re.fullmatch(patron, cad) is not None
                except re.error:
                    ok = False
                res.append(f"[{patron}] '{cad}' => MT:{r_mt} | REGEX:{'SI' if ok else 'NO'}")
        try:
            with open('resultados.txt','w',encoding='utf-8') as f:
                f.write('\n'.join(res)+'\n')
            self._set_resultados("Se generó 'resultados.txt' (5×N).")
        except Exception as e:
            messagebox.showerror('Error', f"No se pudo escribir 'resultados.txt'\n{e}")

    def _set_resultados(self, texto):
        self.txt.configure(state='normal')
        self.txt.delete('1.0','end')
        self.txt.insert('end', texto)
        self.txt.configure(state='disabled')


#  main
if __name__ == '__main__':
    root = tk.Tk(); App(root); root.mainloop()
